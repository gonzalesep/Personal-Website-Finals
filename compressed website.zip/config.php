<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Replace 'your_password' with your actual MySQL root password
define('DB_NAME', 'personalweb'); // Replace 'your_database' with your actual database name
?>
