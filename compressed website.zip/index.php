<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My Personal Static Website</title>
    <link rel="icon" href="img/favicon.png" type="image/x-icon">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/aos.css" rel="stylesheet">
    <!-- main style -->
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>

    <!-- Preloader -->
    <div id="preloader">
        <div id="status">

            <div class="preloader" aria-busy="true" aria-label="Loading, please wait." role="progressbar">
            </div>

        </div>
    </div>
    <!-- ./Preloader -->
    
    <!-- header -->
    <header class="navbar-fixed-top">
        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#experience">Experience</a></li>
                <li><a href="#projects">Portfolio</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>
    <!-- ./header -->
    
    <!-- home -->
    <div class="section" id="home" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="disply-table">
                <div class="table-cell" data-aos="fade-up" data-aos-delay="0">
                    <h4>Eirollits L.A P. Gonzales</h4>
                    <h1>Welcome<br/> to my website!</h1> </div>
            </div>
        </div>
    </div>
    <!-- ./home -->
    
    <!-- about -->
    <div class="section" id="about">
        <div class="container">
            <div class="col-md-6" data-aos="fade-up">
                <h4>01</h4>
                <h1 class="size-50">Get to<br /> Know me</h1>
                <div class="h-50"></div>
                <p>Results-oriented IT professional with a lot years of experience in Website Programming.</p>
                <p>Proven expertise in python and javascript programming languages, system architecture, and cybersecurity, coupled with a strong commitment to optimizing technology solutions..</p>
                <div class="h-50"></div> <img src="img/Signature.png" width="300" alt="" />
                <div class="h-50"></div>
            </div>
            <div class="col-md-6 about-img-div">
                <div class="about-border" data-aos="fade-up" data-aos-delay=".5"></div>
                <img src="img/about-img.jpg" width="400" class="img-responsive" alt="" align="right" data-aos="fade-right" data-aos-delay="0" />
            </div>
        </div>
    </div>
    <!-- ./about -->
    
    <!-- experience  -->
    <div class="section" id="experience">
        <div class="container">
            <div class="col-md-12">
                <h4>02</h4>
                <h1 class="size-50">My <br /> Experience</h1>
                <div class="h-50"></div>
            </div>
            <div class="col-md-12">
                <ul class="timeline">
                    <li class="timeline-event" data-aos="fade-up">
                        <label class="timeline-event-icon"></label>
                        <div class="timeline-event-copy">
                            <p class="timeline-event-thumbnail">March 2031 - Present</p>
                            <h3>SENIOR WEB DEVELOPER</h3>
                            <h4>CLOUD IT</h4>
                            <p><strong>Share ideas that help everyone win and ensure being proactive in dominating situations. As time goes on, a new way of doing things, influenced by generation X, is moving towards a more efficient cloud solution. Content created by users in real-time will connect with different points for offshoring.

</strong>
                        </div>
                    </li>
                    <li class="timeline-event" data-aos="fade-up" data-aos-delay=".2">
                        <label class="timeline-event-icon"></label>
                        <div class="timeline-event-copy">
                            <p class="timeline-event-thumbnail">December 2029 - March 2031</p>
                            <h3>WEB DEVELOPER</h3>
                            <h4>CLOUD IT</h4>
                            <p><strong>Take advantage of easy opportunities to find a valuable activity for beta testing. Go beyond the digital divide by getting more clicks through DevOps. Immersing nanotechnology in the information flow will ensure a comprehensive approach, not just concentrating on profits.

</strong></p>
                        </div>
                    </li>
                    <li class="timeline-event" data-aos="fade-up" data-aos-delay=".4">
                        <label class="timeline-event-icon"></label>
                        <div class="timeline-event-copy">
                            <p class="timeline-event-thumbnail">July 2010 - December 20291</p>
                            <h3>JUNIOR WEB DESIGNER</h3>
                            <h4>ADAPSENSE</h4>
                            <p><strong>Implementing change management in podcasting workflows to create a framework. Moving key performance indicators offline seamlessly to maximize long-term success. Focusing on the start-up mentality, closely monitoring progress, and conducting a thorough analysis to achieve convergence in cross-platform integration.</strong>
                        </div>
                    </li>
                    <li class="timeline-event" data-aos="fade-up" data-aos-delay=".4">
                        <label class="timeline-event-icon"></label>
                        <div class="timeline-event-copy">
                            <p class="timeline-event-thumbnail">September 2026 - June 2028</p>
                            <h3>WEB DESIGN INTERN</h3>
                            <h4>ADAPSENSE</h4>
                            <p><strong>Work together to oversee empowered markets through plug-and-play networks. Efficiently delay engagement with B2C users until after experiencing the benefits of the installed base. Visually represent customer-directed convergence without relying on revolutionary Return on Investment (ROI).</strong>
                        </div>
                    <li class="timeline-event" data-aos="fade-up" data-aos-delay=".4">
                        <label class="timeline-event-icon"></label>
                        <div class="timeline-event-copy">
                            <p class="timeline-event-thumbnail">August 2022 - May 2026</p>
                            <h3>NATIONAL UNIVERSITY - FAIRVIEW</h3>
                            <h4>BACHELOR OF SCIENCE IN INFORMATION TECHONOLOGY - MI</h4> 
                            <p><strong>Information Technology - Web Development Track
GPA: 3.90</strong>

                        </div>
                    <li class="timeline-event" data-aos="fade-up" data-aos-delay=".4">
                        <label class="timeline-event-icon"></label>
                        <div class="timeline-event-copy">
                            <p class="timeline-event-thumbnail">August 2016 - May 2022
</p>
                            <h3>ST. THERESA'S SCHOOL OF NOVALICHES</h3>
                            <h4>(STEM) SCIENCE, TECHNOLOGY, ENGINEERING AND MATHEMATICS</h4>
                            <p><strong>GPA: 3.95</strong>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- ./experience -->
    
     <div class="section" id="projects">
        <div class="container">
            <div class="col-md-12">
                <h4>03</h4>
                <h1 class="size-50">My <br /> Portfolio</h1> 
            </div>
            <!-- main container -->
            <div class="main-container portfolio-inner clearfix">
                <!-- portfolio div -->
                <div class="portfolio-div">
                    <div class="portfolio">
                        <!-- portfolio_filter -->
                        <div class="categories-grid wow fadeInLeft">
                            <nav class="categories">
                                <ul class="portfolio_filter">
                                    <li><a href="" class="active" data-filter="*">All</a></li>
                                </ul>
                            </nav>
                        </div>
                        <!-- portfolio_filter -->
                        
                        <!-- portfolio_container -->
                        <div class="no-padding portfolio_container clearfix" data-aos="fade-up">
                            <!-- single work -->
                            <div class="col-md-4 col-sm-6  fashion logo">
                                 <img src="img/portfolio/01.jpg" alt="image" class="img-responsive" />
                                    <div class="portfolio_item_hover">
                                        <div class="portfolio-border clearfix">
                                            <div class="item_info"> <span> </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- end single work -->
                            
                            <!-- single work -->
                            <div class="col-md-4 col-sm-6 ads graphics">
                               <img src="img/portfolio/03.png" alt="image" class="img-responsive" />
                                    <div class="portfolio_item_hover">
                                        <div class="portfolio-border clearfix">
                                            <div class="item_info"> </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- end single work -->
                            
                            <!-- single work -->
                            <div class="col-md-4 col-sm-6 photography">
                                <img src="img/portfolio/02.jpg" alt="image" class="img-responsive" />
                                    <div class="portfolio_item_hover">
                                        <div class="portfolio-border clearfix">
                                            <div class="item_info"></div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- end single work -->
                            
                            <!-- single work -->
                            <div class="col-md-4 col-sm-6 fashion ads">
                                <img src="img/portfolio/04.png" alt="image" class="img-responsive" />
                                    <div class="portfolio_item_hover">
                                        <div class="portfolio-border clearfix">
                                            <div class="item_info"> </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- end single work -->                     

                        </div>
                        <!-- end portfolio_container -->
                    </div>
                    <!-- portfolio -->
                </div>
                <!-- end portfolio div -->
            </div>
            <!-- end main container -->
        </div>
    </div>

    <!-- ./projects -->
    
    <!-- contact -->
    <div class="section" id="contact">
        <div class="container">
            <div class="col-md-12">
                <h4>04</h4>
                <h1 class="size-50">Contact  Me</h1>
                <div class="h-50"></div>
            </div>
            <div class="col-md-4" data-aos="fade-up">

                <h3> Mobile Number</h3>
                <p>(+63) 9691234567</p>
                <h3>Email</h3>
                <p>GONZALESEIROLLITS@GMAIL.COM</p>

                <h3>Social Network</h3>

                <ul class="social">
                    <li><a href="https://www.facebook.com/eirollits.gonzales/"><i class="ion-social-facebook"></i></a></li>
                    <li><a href="https://twitter.com/EirollitsG"><i class="ion-social-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/eiro.g/""><i class="ion-social-instagram"></i></a></li>
                    <li><a href="https://github.com/gonzalesep""><i class="ion-social-github"></i></a></li>
                </ul>
                <div class="clearfix"></div>
                <div class="h-50"></div>
            </div>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8" data-aos="fade-up">
<form class="contact-bg" id="contact-form" name="contact" action="connect.php" method="post" novalidate="novalidate">
                <div class="form-group row">
                    <div class="col-md-6">
                        <label for="last_name">Last Name:</label>
                        <input type="text" id="last_name" name="last_name" class="form-control" placeholder="Last Name" />
                    </div>
                    <div class="col-md-6">
                        <label for="first_name">First Name:</label>
                        <input type="text" id="first_name" name="first_name" class="form-control" placeholder="First Name" />
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-6">
                        <label for="address">Address:</label>
                        <input type="text" id="lot_block" name="lot_block" class="form-control" placeholder="Lot/Block" />
                    </div>
                    <div class="col-md-6">
                        <input type="text" id="street" name="street" class="form-control" placeholder="Street" />
                    </div>
                </div>
                <div class="form-group">
                    <input type="text" id="place" name="place" class="form-control" placeholder="Place/Subdivision" />
                </div>
                <div class="form-group">
                    <label for="city">City/Municipality:</label>
                    <select id="city" name="city" class="form-control">
                        <option value="">Select City/Municipality</option>
                <option value="Manila">Manila</option>
   		    <option value="Caloocan">Caloocan</option>
    		    <option value="Las Piñas">Las Piñas</option>
   		    <option value="Makati">Makati</option>
   		    <option value="Malabon">Malabon</option>
   		    <option value="Mandaluyong">Mandaluyong</option>
  		    <option value="Marikina">Marikina</option>
   		    <option value="Muntinlupa">Muntinlupa</option>
   		    <option value="Navotas">Navotas</option>
   		    <option value="Parañaque">Parañaque</option>
   		    <option value="Pasay">Pasay</option>
   		    <option value="Pasig">Pasig</option>
   		    <option value="Pateros">Pateros</option>
   		    <option value="Quezon City">Quezon City</option>
                <option value="Other...">Other...</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="baranggay">Baranggay:</label>
                    <input type="text" id="baranggay" name="baranggay" class="form-control" placeholder="Baranggay" />
                </div>
                <div class="form-group">
                    <label for="province">Province:</label>
                    <select id="province" name="province" class="form-control">
                        <option value="">Select Province</option>
<option value="Abra">Abra</option>
<option value="Agusan del Norte">Agusan del Norte</option>
<option value="Agusan del Sur">Agusan del Sur</option>
<option value="Aklan">Aklan</option>
<option value="Albay">Albay</option>
<option value="Antique">Antique</option>
<option value="Apayao">Apayao</option>
<option value="Aurora">Aurora</option>
<option value="Basilan">Basilan</option>
<option value="Bataan">Bataan</option>
<option value="Batanes">Batanes</option>
<option value="Batangas">Batangas</option>
<option value="Benguet">Benguet</option>
<option value="Biliran">Biliran</option>
<option value="Bohol">Bohol</option>
<option value="Bukidnon">Bukidnon</option>
<option value="Bulacan">Bulacan</option>
<option value="Cagayan">Cagayan</option>
<option value="Camarines Norte">Camarines Norte</option>
<option value="Camarines Sur">Camarines Sur</option>
<option value="Camiguin">Camiguin</option>
<option value="Capiz">Capiz</option>
<option value="Catanduanes">Catanduanes</option>
<option value="Cavite">Cavite</option>
<option value="Cebu">Cebu</option>
<option value="Cotabato">Cotabato</option>
<option value="Davao de Oro">Davao de Oro</option>
<option value="Davao del Norte">Davao del Norte</option>
<option value="Davao del Sur">Davao del Sur</option>
<option value="Davao Occidental">Davao Occidental</option>
<option value="Davao Oriental">Davao Oriental</option>
<option value="Dinagat Islands">Dinagat Islands</option>
<option value="Eastern Samar">Eastern Samar</option>
<option value="Guimaras">Guimaras</option>
<option value="Ifugao">Ifugao</option>
<option value="Ilocos Norte">Ilocos Norte</option>
<option value="Ilocos Sur">Ilocos Sur</option>
<option value="Iloilo">Iloilo</option>
<option value="Isabela">Isabela</option>
<option value="Kalinga">Kalinga</option>
<option value="La Union">La Union</option>
<option value="Laguna">Laguna</option>
<option value="Lanao del Norte">Lanao del Norte</option>
<option value="Lanao del Sur">Lanao del Sur</option>
<option value="Leyte">Leyte</option>
<option value="Maguindanao del Norte">Maguindanao del Norte</option>
<option value="Maguindanao del Sur">Maguindanao del Sur</option>
<option value="Marinduque">Marinduque</option>
<option value="Masbate">Masbate</option>
<option value="Metro Manila">Metro Manila</option>
<option value="Misamis Occidental">Misamis Occidental</option>
<option value="Misamis Oriental">Misamis Oriental</option>
<option value="Mountain Province">Mountain Province</option>
<option value="Negros Occidental">Negros Occidental</option>
<option value="Negros Oriental">Negros Oriental</option>
<option value="Northern Samar">Northern Samar</option>
<option value="Nueva Ecija">Nueva Ecija</option>
<option value="Nueva Vizcaya">Nueva Vizcaya</option>
<option value="Occidental Mindoro">Occidental Mindoro</option>
<option value="Oriental Mindoro">Oriental Mindoro</option>
<option value="Palawan">Palawan</option>
<option value="Pampanga">Pampanga</option>
<option value="Pangasinan">Pangasinan</option>
<option value="Quezon">Quezon</option>
<option value="Quirino">Quirino</option>
<option value="Rizal">Rizal</option>
<option value="Romblon">Romblon</option>
<option value="Samar">Samar</option>
<option value="Sarangani">Sarangani</option>
<option value="Siquijor">Siquijor</option>
<option value="Sorsogon">Sorsogon</option>
<option value="South Cotabato">South Cotabato</option>
<option value="Southern Leyte">Southern Leyte</option>
<option value="Sultan Kudarat">Sultan Kudarat</option>
<option value="Sulu">Sulu</option>
<option value="Surigao del Norte">Surigao del Norte</option>
<option value="Surigao del Sur">Surigao del Sur</option>
<option value="Tarlac">Tarlac</option>
<option value="Tawi-Tawi">Tawi-Tawi</option>
<option value="Zambales">Zambales</option>
<option value="Zamboanga del Norte">Zamboanga del Norte</option>
<option value="Zamboanga del Sur">Zamboanga del Sur</option>
<option value="Zamboanga Sibugay">Zamboanga Sibugay</option>
                   </select>
                </div>
                <div class="form-group">
                    <label for="country">Country:</label>
                    <select id="country" name="country" class="form-control">
                        <option value="">Select Country</option>
                            <option value="India">India</option>
    			<option value="China">China</option>
			    <option value="Indonesia">Indonesia</option>
			    <option value="Pakistan">Pakistan</option>
			    <option value="Bangladesh">Bangladesh</option>
			    <option value="Japan">Japan</option>
			    <option value="Philippines">Philippines</option>
			    <option value="Vietnam">Vietnam</option>
			    <option value="Iran">Iran</option>
			    <option value="Turkey">Turkey</option>
			    <option value="Thailand">Thailand</option>
			    <option value="Myanmar">Myanmar</option>
			    <option value="South Korea">South Korea</option>
			    <option value="Iraq">Iraq</option>
			    <option value="Afghanistan">Afghanistan</option>
			    <option value="Saudi Arabia">Saudi Arabia</option>
			    <option value="Uzbekistan">Uzbekistan</option>
			    <option value="Yemen">Yemen</option>
			    <option value="Malaysia">Malaysia</option>
			    <option value="Nepal">Nepal</option>
			    <option value="North Korea">North Korea</option>
			    <option value="Syria">Syria</option>
			    <option value="Sri Lanka">Sri Lanka</option>
			    <option value="Kazakhstan">Kazakhstan</option>
			    <option value="Cambodia">Cambodia</option>
			    <option value="Jordan">Jordan</option>
			    <option value="Azerbaijan">Azerbaijan</option>
			    <option value="Tajikistan">Tajikistan</option>
			    <option value="United Arab Emirates">United Arab Emirates</option>
			    <option value="Israel">Israel</option>
			    <option value="Laos">Laos</option>
			    <option value="Kyrgyzstan">Kyrgyzstan</option>
			    <option value="Turkmenistan">Turkmenistan</option>
			    <option value="Singapore">Singapore</option>
 			    <option value="State of Palestine">State of Palestine</option>
 			    <option value="Lebanon">Lebanon</option>
 			    <option value="Oman">Oman</option>
 			    <option value="Kuwait">Kuwait</option>
 			    <option value="Georgia">Georgia</option>
 			    <option value="Mongolia">Mongolia</option>
  			    <option value="Armenia">Armenia</option>
  		          <option value="Qatar">Qatar</option>
  			    <option value="Bahrain">Bahrain</option>
 			    <option value="Timor-Leste">Timor-Leste</option>
 			    <option value="Cyprus">Cyprus</option>
 			    <option value="Bhutan">Bhutan</option>
 			    <option value="Maldives">Maldives</option>
 			   <option value="Brunei">Brunei</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="contact_number_country_code">Contact No:</label>
                    <div class="input-group">
                        <select id="contact_number_country_code" name="contact_number_country_code" class="form-control">
                            <option value="">Select Country Code</option>
                   <option value="">Select Country Code</option>
           		 <option value="+63">+63 (Philippines)</option>
           		 <option value="+91">+91 (India)</option>
           		 <option value="+86">+86 (China)</option>
           		 <option value="+62">+62 (Indonesia)</option>
           		 <option value="+92">+92 (Pakistan)</option>
            	 <option value="+880">+880 (Bangladesh)</option>
           		 <option value="+81">+81 (Japan)</option>
           		 <option value="+84">+84 (Vietnam)</option>
           		 <option value="+98">+98 (Iran)</option>
           		 <option value="+90">+90 (Turkey)</option>
                        </select>
                        <input type="text" id="contact_number" name="contact_number" class="form-control" placeholder="Enter additional digits">
                    </div>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="Email" />
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" class="form-control" placeholder="Password" />
                </div>
                <div class="form-group">
                    <label for="repeat_password">Repeat Password:</label>
                    <input type="password" id="repeat_password" name="repeat_password" class="form-control" placeholder="Repeat Password" />
                </div>
                <div class="form-group">
        <button id="submit" type="submit" name="submit" class="btn btn-glance">Send</button>
                </div>
            </form>
        </div>
    </div>
</div>



    <!-- ./contact -->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!--  plugins  -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.form.js"></script>
    <script src="js/jquery.validate.min.js"></script>

    <!--  main script  -->
    <script src="js/custom.js"></script>
</body>

</html>